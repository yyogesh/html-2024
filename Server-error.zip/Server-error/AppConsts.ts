import { PaymentMasterCommissionSharingDto } from "./service-proxies/service-proxies";

export class AppConsts {
    static readonly tenancyNamePlaceHolderInUrl = '{TENANCY_NAME}';

    static remoteServiceBaseUrl: string;
    static remoteServiceBaseUrlFormat: string;
    static newNewMemberPortalUrl: string;
    static loginEnabled: string;
    static loginInternalServerErrorAction: string;
    static appBaseUrl: string;
    static appBaseHref: string; // returns angular's base-href parameter value if used during the publish
    static appBaseUrlFormat: string;
    static recaptchaSiteKey: string;
    static subscriptionExpireNootifyDayCount: number;
    static readonly TenantMaxBackDays = 9999;
    static readonly CallingADMIN = 'ADMIN';
    static readonly CallingMEMBER = 'MEMBER';
    static readonly CallingMemberAE = 'MEMBERAE';
    static readonly CallingAdminAE = 'ADMINAE';
    static localeMappings: any = [];

    static readonly userManagement = {
        defaultAdminUserName: 'admin',
    };

    static readonly localization = {
        defaultLocalizationSourceName: 'FPE',
    };

    static readonly organization = {
        entityTypeFullName: 'SEB.FPE.Organizations.Organization',
    };

    static readonly authorization = {
        encrptedAuthTokenName: 'enc_auth_token',
        AuthLogintype: 'Abp.Authorization.Logintype'
    };

    static readonly loginErrorActions = {
        refresh: 'refresh',
        logout: 'logout',
        none: 'none'
    };

    static readonly grid = {
        defaultPageSize: 10,
    };

    static readonly MinimumUpgradePaymentAmount = 1;

    static readonly OrgYInfo = 'Y-Info';

    /// <summary>
    /// Gets current version of the application.
    /// It's also shown in the web page.
    /// </summary>
    static readonly WebAppGuiVersion = '9.0.1.0';

    static readonly MaxPanelRecordsToShow: 5;

    static readonly TenantCompanyAddress = 'Company';
    static readonly TenantFinanceAddress = 'Finance';
    static readonly skipReason = 'skipReason';
    static readonly orgnizationRoleTypes = {
        planSponsor: 'PlanSponsor',
        broker: 'Advisor',
        Tenant: 'Tenant',
        Carrier: 'Carrier',
        TPA: 'TPA',
        BrokerageFirm: 'BrokerageFirm',
        Payroll: 'Payroll'
    };

    static readonly jobFrequencyTypes = {
        minutely: 'Minutely',
        hourly: 'Hourly',
        daily: 'Daily',
        weekly: 'Weekly',
        biWeekly: 'BiWeekly',
        monthly: 'Monthly',
        semiMonthly: 'SemiMonthly',
        yearly: 'Yearly',
    };

    static readonly lookupKeyType = {
        adjudicator: 'Adjudicator',
        carrier: 'Carrier',
        planSponsor: 'PlanSponsor',
        headOffice: 'HeadOffice',
        brokerageFirm: 'BrokerageFirm',
        Member: 'Member',
        Brokerage: 'Brokerage',
        Payroll: 'Payroll',
        Advisor: 'Advisor',
    };

    static readonly relationShipType = {
        spouse: 'Spouse',
        commonLaw: 'CommonLaw',
        student: 'Student',
        child: 'Child',
        sister: 'Sister',
        brother: 'Brother',
        other: 'Other',
        disabled: 'Disabled',
        ineligible: 'Ineligible',
        estate: 'Estate',
        charity: 'Charity',
        otherEntity: 'Other entity',
        NewMemberEnrolment: 'NewMemberEnrolment',
        ExceptionForAdmin: 'ExceptionForAdmin',
        SpouseOrCommonLaw: 'Spouse or Common Law'
    };

    static readonly relationShipFrenchType = {
        spouse: 'Conjoint',
        commonLaw: 'Common Law',
        student: 'Étudiant',
        child: 'Enfant',
    };

    static readonly benefitSettingType = {
        SpouseAgeLimit: 'MinimumSpouseAge',
        ChildUpperAgeLimit: 'ChildUpperAgeLimit',
        StudentUpperAgeLimit: 'StudentUpperAgeLimit',
        StudentUpperAgeLimitQC: 'StudentUpperAgeLimitQC',
        DependentSelectionType: 'DependentSelectionType',
        DivisionDefaultTaxProvinceType: 'DivisionDefaultTaxProvinceType',
        COBConfirmation: 'COBConfirmation'
    };

    static readonly smokerStaus = {
        NonSmokerEn: 'Non smoker',
        NonSmokerFr: 'Non fumeur',
        SmokerEn: 'Smoker',
        SmokerFr: 'Fumeur'
    };

    static readonly tenantSettingType = {
        MemberDataChangeDateLimit: 'MemberDataChangeDateLimit',
        StudentCertificationReviewRequired: "StudentCertificationReviewRequired",
        StudentCertificateDocumentRequired: "StudentCertificateDocumentRequired",
        NSFCharges: "NSFCharges",
        ReviewRequiredMembersCreatedByPlanSponsor: 'ReviewRequiredMembersCreatedByPlanSponsor',
    };

    static readonly customPermission = {
        MemberDataChangeDateLimit: 'Customs.MemberDataChangeDateLimit.Applicable'
    };

    static readonly uploadFilePropType = {
        primaryFileProperty: 'imgfile',
        secondaryFileProperty: 'imgfileSecondary'
    };
    static readonly uploadFileValueType = {
        primaryFileValue: 'imgfile',
        secondaryFileValue: 'secondaryImgFile'
    };

    static readonly jsonTypes = {
        NEM: 'NEM',
        CategoryBasedHCSA: 'CategoryBasedHCSA'
    };

    static readonly lookupKeys = {
        title: 'Title',
        benefitEligbility: 'BenefitEligibility',
        preferredlanguage: 'PreferredLanguage',
        personAddressType: 'PersonAddressType',
        personEmailType: 'PersonEmailType',
        dataSource: 'DataSource',
        dataOrigin: 'DataOrigin',
        organizationRoleType: 'OrganizationRoleType',
        organizationUnitType: 'OrganizationUnitType',
        organizationAddressType: 'OrganizationAddressType',
        organizationPhoneType: 'OrganizationPhoneType',
        preferredCommunicationMethod: 'PreferredCommunicationMethod',
        carrierPremiumLayout: 'CarrierPremiumLayout',
        carrierPolicyLayout: 'CarrierPolicyLayout',
        emailtype: 'PersonEmailType',
        payRollLayout: 'PayRollLayout',
        finTranType: 'FinancialTransactionType',
        finInstrType: 'FinancialInstrumentType',
        currCode: 'CurrencyCode',
        bankNumber: 'BankNumber',
        phoneFormatType: 'PhoneFormatType',
        personPhoneType: 'PersonPhoneType',
        phoneCapabilities: 'PhoneCapabilities',
        payrollFrequency: 'PayrollFrequency',
        contactType: 'ContactType',
        calculatorStepName: 'CalculatorStepName',
        calculatorStepStatus: 'CalculatorStepStatus',
        benefitType: 'BenefitType',
        availableToParticipants: 'AvailableToParticipant',
        jobFrequency: 'JobFrequency',
        jobRunStatus: 'JobRunStatus',
        jobType: 'JobType',
        eventCategory: 'EventCategory',
        eventType: 'EventType',
        gender: 'Gender',
        smoker: 'SmokerStatus',
        communicationType: 'Communicationtype',
        communicationTrigger: 'CommunicationTrigger',
        reminderPriority: 'ReminderPriority',
        relationshipCategory: 'dependenttype',
        relationshipCharacteristicType: 'RelationshipCharacteristicType',
        settingDataType: 'SettingDataType',
        beneficiaryRelationshipCategory: 'Beneficiary',
        fileProcessType: 'FileProcessType',
        fileFormat: 'FileFormat',
        parseType: 'ParseType',
        dataType: 'DataType',
        fileParseTypeName: 'FixedDataLength', //
        jobFrequencyTypeName: 'Onetime', //
        benifitClassFlatTypeName: 'Flat', //
        benifitClassPercentAllocateTypeName: 'Percent', //
        benefitClassRateVolumnSource: 'BenefitClassRateVolumnSource',
        benefitClassRateType: 'BenefitClassRateType',
        benefitCostShareType: 'BenefitCostShareType',
        benefitClassRateCalculationType: 'BenefitClassRateCalculationType',
        benefitClassRateBenefitRate: 'BenefitClassRateBenefitRate',
        flexAllocationtype: 'FlexAllocationtype',
        benefitClassRateCalculationFactor: 'BenefitClassRateCalculationFactor',
        benefitLevelLabel: 'BenefitLevelLabel',
        benefitLevelCoverageLabel: 'BenefitLevelCoverageLabel',
        LibraryBenefitDropdownTextNA: 'NA',
        tenantCategoryType: 'CategoryType',
        jsonType: 'JsonType',
        smokerStatus: 'SmokerStatus',
        FirstNationStatus: 'FirstNationStatus',
        All: 'All',
        divisionProvinceType: 'ProvinceType',
        taxType: 'TaxType',
        effectiveDateType: 'EffectiveDateType',
        effectiveDateNumberOfMonth: 'numberofmonth',
        effectiveDateDayOfMonth: 'Dayofmonth',
        reductionType: 'ReductionType',
        reductionCalculationType: 'ReductionCalculationType',
        reductionMinimumType: 'ReductionMinimumType',
        eligibilityBasedOn: 'EligibilityBasedOn', //
        flexdetail: 'FlexDetail',
        lockLevel: 'FlexLockLevel',
        paidOutFrequency: 'FlexPaidOutFrequency',
        prorateFrequency: 'FlexProrateFrequency',
        benfitStatus: 'BenefitStatus', //status of a benefit in a class
        planMemberStatus: 'PlanMemberStatus', // Member status like LTD/STD//MAT
        planMemberBenefitStatus: 'PlanMemberBenefitStatus', //Eligible//Inelgible
        planBenefitStatus: 'PlanBenefitStatus', // class Status act/suspended
        memberBenefitStatus: 'MemberBenefitStatus', // active/Terminated/Waived enrollment table
        planSponsorStatus: 'PlanSponsorStatus', // PlanSponsor Status act/suspended
        divisionStatus: 'DivisionStatus',
        classStatus: 'ClassStatus',
        profileType: 'ProfileType',
        profileStatus: 'ProfileStatus',
        benefitPeriodRuleName: 'BenefitPeriodRuleName',
        calculatorProfileType: 'CalculatorProfileType',
        calculatorProfileStatus: 'CalculatorProfileStatus',
        calculatorCycleStatus: 'CalculatorCycleStatus',
        calculatorCycleStepStatus: 'CalculatorCycleStepStatus',
        billThresholdType: 'BillThresholdType',
        reviewType: 'ReviewType',
        benefitLinkingType: 'BenefitLinkingType',
        lockinCalculationDate: 'LockinCalculationDate',
        eliminationPeriodType: 'EliminationPeriodType',
        benefitClassCoverageType: 'BenefitClassCoverageType',
        roundingCriteria: 'RoundingCriteria',
        designationStatus: 'DesignationStatus',
        Occupation: 'Occupation',
        NotApplicable: 'N/A',
        benefitCode: 'BenefitCode',
        DocumentType: 'DocumentType',
        PlanDocuments: 'PlanDocuments',
        OrganizationSetting: 'OrganizationSetting',
        TenantSetting: 'TenantSetting',
        DefaultLanguage: 'DefaultLanguage',
        BreakUpBillsByDivision: 'BreakUpBillsByDivision',
        ShowMemberBilledBreakOnDivision: 'ShowMemberBilledBreakOnDivision',
        OrganizationText: 'OrganizationText',
        OptionSelectionMode: 'optionselectionmode',
        WindowType: 'Windowtype',
        statusChange: 'StatusChange',
        retroCalculationFrequency: 'RetroCalculationFrequency',
        maritalStatus: 'MaritalStatus',
        dependentStatus: 'DependentStatus',
        plansponsorAdministrator: 'Plansponsor Administrator',
        brokerageAdministratorRole: 'Brokerage Administrator',
        advisorAdministratorRole: 'Advisor Administrator',
        daily: 'Daily',
        monthly: 'Monthly',
        custom: 'Custom',
        OptOutOptionName: 'OptOutOptionName',
        TenantTextType: 'TenantTextType',
        RAMQMessage: 'RAMQMessage',
        TPAAdministrator: 'TPA Administrator',
        Administrator: 'Administrator',
        Irrevocable: 'Irrevocable',
        Revocable: 'Revocable',
        ReasonForSpouse: 'ReasonForSpouse',
        ReasonForChild: 'ReasonForChild',
        NewMemberEnrolment: 'NewMemberEnrolment',
        LossOfCoverage: 'LossOfCoverage',
        Marriage: 'Marriage',
        Birth: 'Birth',
        AdoptionLegalGuardianship: 'AdoptionLegalGuardianship',
        Student: 'Student',
        ShowSalaryInfoInBilling: 'ShowSalaryInfoInBilling',
        ShowOptionNameInBilling: 'ShowOptionNameInBilling',
        ShowMemberBenefitDetails: 'ShowMemberBenefitDetails',
        PassSalaryColumnInBilling: 'PassSalaryColumnInBilling',
        PassOptionColumnInBilling: 'PassOptionColumnInBilling',

        HoldBillGenerationForPS: 'HoldBillGenerationForPS',
        IncludeInTestCarrierFileForSunlife: 'IncludeInTestCarrierFileForSunlife',
        EnableSunlifeTestFileGeneration: 'EnableSunlifeTestFileGeneration',
        carrierContactType: 'CarrierContactType',
        pensionAllocationType: 'PensionAllocationType',
        StopCommunication: 'StopCommunication',
        SupportsHRIS: 'SupportsHRIS',

        MemberNumberGeneration: 'MemberNumberGeneration',
        MemberNumberLength: 'MemberNumberLength',
        MemberNumberPrefix: 'MemberNumberPrefix',
        MemberNumberSuffix: 'MemberNumberSuffix',

        TenantMemberNumberGeneration: 'TenantMemberNumberGeneration',
        TenantMemberNumberLength: 'TenantMemberNumberLength',
        TenantMemberNumberPrefix: 'TenantMemberNumberPrefix',
        TenantMemberNumberSuffix: 'TenantMemberNumberSuffix',

        TenantSettingConst: 'TenantSetting',

        EmailStatus: 'EmailStatus',
        SMSStatus: 'SMSStatus',
        Certification: 'Certification',
        PensionAllocationType: 'PensionAllocationType',
        Configuration: 'Configuration',
        CodeSetup: 'CodeSetup',
        Settings: 'Settings',
        YesNo: 'YESNO',
        terminated: 'Terminated',
        bankFileType: 'BankFileType',
        HCSAAdministrationFeeDetail: 'HCSAAdministrationFeeDetail',
        hcsaContributionAmountType: 'HCSAContributionAmountType',

        BrokerStatusType: 'BrokerStatusType',
        LicenseStatus: 'LicenseStatus',
        LicenseType: 'LicenseType',
        LicenseDocumentType: 'LicenseDocumentType',
        BrokerLinkingStatus: 'BrokerLinkingStatus',
        BrokerTPAFee: 'TPAFee',
        CalculationType: 'CalculationType',
        CommissionPaid: 'CommissionPaid',
        Frequency: 'Frequency',
        Active: 'Active',
        EmployerMatchType: 'EmployerMatchtype',
        PendingReview: 'Pending Review',
        LockInPeriod: 'LockInPeriod',
        LockInDate: 'LockInDate',
        LockInApplicable: 'LockInApplicable',
        ModuleStatus: 'ModuleStatus',
        ModuleStepUpLimit: 'ModuleStepUpLimit',
        ModuleStepDownLimit: 'ModuleStepDownLimit',
        ModuleCostShareType: 'ModuleCostShareType',
        ModuleCredits: 'ModuleCredits',
        PlanType: "PlanType",
        FlexSpendingWithAnyCredits: "FlexSpendingWithAnyCredits",
        Flex: "Flex",
        ModularWithFlex: "ModularWithFlex",

        TaxationProvince: 'TaxationProvince',
        PolicyStatus: 'PolicyStatus',
        PolicyStatus_PendingCommissions: 'PendingCommissions',
        bankFileStatus: 'BankFileStatus',
        bankFileTransactionType: 'BankFileTransactionType',
        paymentInvoiceType: 'paymentInvoiceType',
        paymentStatus: 'paymentStatus',
        HolidayStatus: 'HolidayStatus',
        BillStatus: 'BillStatus',
        AdhocCreditStatus: 'AdhocCreditStatus',
        fileProcessState: 'FileProcessState',

        commissionType: 'CommissionType',
        commissionType_NotApplicable: 'NotApplicable',
        commissionType_ScaledCommissionByPercentOfPremium: 'ScaledCommissionByPercentOfPremium',
        commissionType_ScaledCommissionByOption: 'ScaledCommissionByOption',
        commissionRateType: 'CommissionRateType',
        commissionRateType_FlatCommissionRate: 'FlatCommissionRate',
        commissionRateType_PercentCommissionRate: 'PercentCommissionRate',
        AdhocCommOrganizationType: 'AdhocCommOrganizationType',
        AdhocEventStatus: 'AdhocEventStatus',
        AdhocNotApplicable: 'NotApplicable',
        NSFReason: 'NSFReason',
        TraditionalPlanType: "Traditional",
        AdvisorAdministrator: 'Advisor',
        BrokerageAdministrator: 'Brokerage',
        MemberRole: 'Member',
        TenantAddressType: 'TenantAddressType',
        calculationType_Forecasted: "Forecasted",
        calculationType_BilledByTPA: "BilledByFlexPlus",
        calculationType_BilledByCarrier: "BilledByCarrier",
        commissionPaid_InArrears: "InArrears",
        commissionPaid_InAdvance: "InAdvance",
        holdback_No: "NO",
        moduleInstructions: 'ModuleInstructions',
        statementType: 'StatementType',
        ManagePaymentTracking: 'ManagePaymentTracking',
        CarrierRemittancePaymentType: 'CarrierRemittancePaymentType',
        CostCenter: 'CostCenter',
        costCenterStatus: 'CostCenterStatus',
        OrganizationUserGuideUrl: 'OrganizationUserGuideUrl',
        BenefitEOIStatus: 'BenefitEOIStatus',
        Inactive: 'Inactive',
        AEEventStatus: 'AEEventStatus',
        AEEventSetup: 'AEEventSetup',
        HideCostOnMemberPortal: 'HideCostOnMemberPortal',
        AnnualEnrollment: 'AnnualEnrollment',
        BilingualCommunication: 'BilingualCommunication',
        TenantControls: 'TenantControls',
        RoleGroup: 'RoleGroup',
        ConsentMessage: 'ConsentMessage',
        AttestationParagraph5: 'AttestationParagraph5',
        BeneficiaryConsent: 'BeneficiaryConsent',
        BeneficiaryConsent1: 'BeneficiaryConsent1',
        BeneficiaryConsent2: 'BeneficiaryConsent2',
        ConfirmBenefits: 'ConfirmBenefits',
        ConfirmBenefitCheckMsg2: 'ConfirmBenefitCheckMsg2',
        ConfirmBeneficiary: 'ConfirmBeneficiary',
        ConfirmBenefitCheckMsg: 'ConfirmBenefitCheckMsg',
        ConfirmBenefitCheckMsg1: 'ConfirmBenefitCheckMsg1',
        MemberCOBOnRed: 'MemberCOBOnRed',
        MemberCOBNote: 'MemberCOBNote',
        AECancelled: "AECancelled",
        AEOnHold: "AEOnHold",
        OpenForMembers: "OpenForMembers",
        ReadyForLaunch: "ReadyForLaunch",
        ClosedForMembers: "ClosedForMembers",
        AEClosed: "AEClosed",
        PayrollFileType: 'PayrollFileType',
        PRIVACYLINKEN: 'Footer_PrivacyLink_English',
        PRIVACYLINKFR: 'Footer_PrivacyLink_French',
        LEGALLINKEN: 'Footer_Legal_English',
        LEGALLINKFR: 'Footer_Legal_French'

    };

    static readonly lookupvalues = {
        grossRate: 'GROSSRATE',
        netRate: 'NETRATE',
        flex: 'FLEX',
        costShare: 'CostShare',
        flat: 'Flat',
        percent: 'PercentageSalary',
        coverage: 'Coverage',
        MemberActiveStatus: 'Active',
        employerPercentage: 'EmployerPercentage',
        employerFlat: 'EmployerFlat',
        employeeFlat: 'EmployeeFlat',
        flexflat: 'Flat',
        flexpercentageOfCost: 'PercentageOfCost',
        PercentOfPay: 'PercentOfPay',
        NoMaxLimit: 'NoMaxLimit',
        MaxPercentUpto: 'MaxPercentUpto',
        MaxAmountUpto: 'MaxAmountUpto',
        ModuleNotApplicable: 'NotApplicable',
        ModulePercentage: 'ModulePercentage',
        PaymentInvoice: 'Invoice',
        PaymentStatus: 'Paid',
        PaymentDeposit: 'Deposit',
        PaymentBinder: 'Binder',
        PaymentTypeCheque: 'Cheque',
        PaymentTypePAP: 'PAP',
        PaymentTypeEFT: 'EFT',
        paymentStatusPaid: 'Paid',
        AccountsPayable: 'AccountsPayable',
        AccountsReceivable: 'AccountsReceivable',
        PaymentStatusReverse: 'Reverse',
        PercentOfPremium: 'PercentOfPremium',
        FlatAmount: 'FlatAmount',
        NotApplicable: 'NotApplicable',
        Outstanding: 'Outstanding',
        PerMember: 'PerMember',
        basicEnrollmentFlow: 'BasicEnrollmentFlow',
        enrollmentWithRecommendation: 'EnrollmentWithRecommendation',
        PaymentStatement: 'StatementManagePaymentTracking',
        PaymentAdvance: 'AdvanceManagePaymentTracking',
        CarrierRemittancePaymentType_Advance: 'Advance',
        CarrierRemittancePaymentType_PremiumRemittance: 'PremiumRemittance',
        CarrierRemittancePaymentType_ClaimFunding: 'ClaimFunding',
        CarrierRemittancePaymentType_BudgettedASO: 'BudgettedASO',
        DependentLife: 'DEPLIFE',
        TPAAdminRetrodatelimit: 'TPAAdminRetrodatelimit',
    };

    static readonly settingKeys = {
        TenantSecondaryLanguage: 'App.TenantManagement.SecondaryLanguageName',
        PersonHierarchyDisplayPanel: 'App.UserManagement.PersonHierarchy.DisplayPanel',
        OrgHierarchyDisplayPanel: 'App.UserManagement.OrgHierarchy.DisplayPanel',
        CalculatorProfileHierarchyDisplayPanel: 'App.UserManagement.CalculatorProfileHierarchy.DisplayPanel',
        CarrierBenefitHierarchyDisplayPanel: 'App.UserManagement.CarrierBenefitHierarchy.DisplayPanel',
        ExportHierarchyDisplayPanel: 'App.UserManagement.ExportHierarchy.DisplayPanel',
        CalculatorScheduleHierarchyDisplayPanel: 'App.UserManagement.CalculatorScheduleHierarchy.DisplayPanel',
        EnvironmentName: 'App.EnvironmentSetting.EnvironmentName',
        EnvironmentBannerVisible: 'App.EnvironmentSetting.BannerVisible',
        EnvironmentBannerDescriptionEnglish: 'App.EnvironmentSetting.BannerDescriptionEnglish',
        EnvironmentBannerDescriptionFrench: 'App.EnvironmentSetting.BannerDescriptionFrench',
        PlanSponsorContactMessageForMemberPortal: 'PlanSponsorContactMessageForMemberPortal',
        PlanSponsorContactMessageForMemberPortalFrench: 'PlanSponsorContactMessageForMemberPortalFrench'
    };


    static readonly benefitType = {
        Accidental: 'Accidental',
        Dental: 'Dental',
        Disability: 'Disability',
        FLEX: 'FLEX',
        Health: 'Health',
        Life: 'Life',
        Travel: 'Travel',
        Vacation: 'Vacation',
        Vision: 'Vision',
        CategoryBasedHCSA: 'CategoryBasedHCSA',
        SpendingAccount: 'SpendingAccount'
    };

    static readonly dateFormat = {
        mmddyyyy: 'MM/DD/YYYY',
        ddmmyyyy: 'DD/MM/YYYY',
        mmddyyyyhms: 'MM/DD/YYYY hh:mm:ss',
        yyyymmdd: 'YYYY-MM-DD',
        yyyymmddhms: 'YYYY-MM-DD hh:mm:ss',
    };

    static readonly fieldMaxMinValue = {
        emailMin: 0,
        emailMax: 50,

        FirsName: 50,
        LastName: 50,
    };

    static readonly memberFileUpload = {
        fileNameLength: 85,
    };

    static readonly benefitLinkingType = {
        MinimumOption: 'MinimumOption',
        Coverage: 'Coverage'
    };

    static readonly DependentSelectTpe = {
        Manual: 'Manual',
        CanNotDeselect: 'CanNotDeselect',
        CanSelect: 'CanSelect',
        AllOrNone: 'AllOrNone'
    };

    static readonly templateType = {
        UploadNewMember: '1',
        UpdateStatusSalary: '2',
        DependentUpload: '3',
        TaxableBenefitUpload: '4',
        Advisor: '5'
    };

    static readonly beneficiaryStatus = {
        Approved: 'Approved',
        Pending: 'Pending',
        Rejected: 'Rejected'
    };

    static readonly calculatorProfileTypes = {
        Carrier: 'Carrier',
        Billing: 'Billing',
        PayrollExtract: 'PayrollExtract',
        PayrollReport: 'PayrollReport'
    };


    static readonly Taxablebenefittype = {
        taxablebenefittype: 'Taxablebenefittype',
        quebectaxablebenefit: 'Quebectaxablebenefit',
        federaltaxablebenefit: 'Federaltaxablebenefit',
        provincialtaxablebenefit: 'Provincialtaxablebenefit'
    };

    static readonly DevisionTaxableBenefitProvince = {
        devisionTaxableBenefitProvince: 'DevisionTaxableBenefitProvince',
        workProvince: 'WorkProvince',
        residenceProvince: 'ResidenceProvince'
    };

    static readonly ReportTypes = {
        Payroll: 'Payroll',
        TaxableBenefit: 'TaxableBenefit',
        RetirementContribution: 'RetirementContribution',
        PremiumRemittanceCooperators: 'PremiumRemittanceCooperators',
        planSponsorDivision: 'planSponsorDivision',
        planSponsorClassReport: 'planSponsorClassReport'
    };

    static readonly TenantName = {
        default: 'FPE'
    };

    static readonly OptionSelectionType = {
        slidders: 'SLIDER',
        Buttons: 'BUTTONS'
    };

    static readonly DependentStatusType = {
        active: 'Active',
        terminate: 'Terminate',
        terminated: 'Terminated',
    };

    static readonly CostCenterStatusType = {
        active: 'Active',
        terminate: 'Terminate',
        terminated: 'Terminated',
    };

    static readonly AvailableToParticipant = {
        Member: 'Member',
        Spouse: 'Spouse',
        Child: 'Child',
        Dependent: 'Dependent',
    };

    static readonly SalaryRuleForBenefit = {
        'SalaryType': [
            { 'BenefitCode': 'LIFE' },
            { 'BenefitCode': 'ADD' },
            { 'BenefitCode': 'CRITICAL' },
            { 'BenefitCode': 'STD' },
            { 'BenefitCode': 'LTD' },
        ],
    };

    static readonly RecalculationReason = {
        BenefitAdded: 'BenefitAdded',
        BenefitModified: 'BenefitModified',
        BenefitDeleted: 'BenefitDeleted',
        GranfatherCoverageAdded: 'GranfatherCoverageAdded',
        GranfatherCoverageModified: 'GranfatherCoverageModified',
        GranfatherCoverageDeleted: 'GranfatherCoverageDeleted',
        SalaryChanged: 'SalaryChanged'
    };

    static readonly entityTypeFullName = {
        Organizations: 'SEB.FPE.Organizations.Organization',
        OrganizationStatus: 'SEB.FPE.Organizations.OrganizationStatus',
        OrganizationSetting: 'SEB.FPE.FPESettings.OrganizationSetting',
        OrganizationTranslation: 'SEB.FPE.Organizations.OrganizationTranslation',
        OrganizationContact: 'SEB.FPE.Organizations.OrganizationContact',
        Person: 'SEB.FPE.Persons.Person',
        PersonPhone: 'SEB.FPE.Persons.PersonPhone',
        PersonEmail: 'SEB.FPE.Persons.PersonEmail',
        OrganizationAddress: 'SEB.FPE.Organizations.OrganizationAddress',
        OrganizationPhone: 'SEB.FPE.Organizations.OrganizationPhone',
        DivisionProvinceTaxType: 'SEB.FPE.Organizations.DivisionProvinceTaxType',
        ContactDivisions: 'SEB.FPE.Organizations.FpeContactOrganizationunits',
        PlanSponsorClass: 'SEB.FPE.Organizations.PlanSponsorClass',
        PlanSponsorClassTranslation: 'SEB.FPE.Organizations.PlanSponsorClassTranslation',
        TenantEffectiveDateMasterTranslation: 'SEB.FPE.Benefits.TenantEffectiveDateMasterTranslation',
        OrgFinancial: 'SEB.FPE.Organizations.OrgFinancial',
        BillingGroupAssignment: 'SEB.FPE.Calculators.BillingGroupAssignment',
        OrganizationNote: 'SEB.FPE.Organizations.OrganizationNote',
        MemberBenefitOverrides: 'SEB.FPE.Members.MemberBenefitOverrides',
        DivisionClassMapping: 'SEB.FPE.Organizations.DivisionClassMapping',
        PersonAddress: 'SEB.FPE.Persons.PersonAddress',
        Country: 'SEB.FPE.Countries.Country',
        RoleGroup: 'SEB.FPE.Authorization.Roles.RoleGroup',
        UserRole: 'Abp.Authorization.Users.UserRole',
        MemberIds: 'SEB.FPE.Members.MemberIds',
        PersonNote: 'SEB.FPE.Persons.PersonNote',
        MemberRelationshipCharacteristic: 'SEB.FPE.Members.MemberRelationshipCharacteristic',
        MemberDependent: 'SEB.FPE.Members.MemberDependent',
        DependentBenefitCoverage: 'SEB.FPE.Members.DependentBenefitCoverage',
        MemberDependentCOBCoverage: 'SEB.FPE.Members.MemberDependentCOBCoverage',
        MemberBenefitBeneficiaryAllocation: 'SEB.FPE.Members.MemberBenefitBeneficiaryAllocation',
        LibraryBenefitClassInclusionDetail: 'SEB.FPE.Benefits.LibraryBenefitClassInclusionDetail',
        LibraryBenefitClassInclusion: 'SEB.FPE.Benefits.LibraryBenefitClassInclusion',
        LibraryBenefitClassInclusionTranslation: 'SEB.FPE.Benefits.LibraryBenefitClassInclusionTranslation',
        BenefitSettingValue: 'SEB.FPE.Benefits.BenefitSettingValue',
        BenefitClassSetting: 'SEB.FPE.Benefits.BenefitClassSetting',
        BenefitSettingTenant: 'SEB.FPE.Benefits.BenefitSettingTenant',
        Member: 'SEB.FPE.Members.Member',
        LibraryBenefitClassCoverageDetail: 'SEB.FPE.Benefits.LibraryBenefitClassCoverageDetail',
        LibraryBenefitClassCoverage_JSON: 'SEB.FPE.Benefits.LibraryBenefitClassCoverage_JSON',
        LibraryBenefitClassCoverageTranslation: 'SEB.FPE.Benefits.LibraryBenefitClassCoverageTranslation',
        LibraryBenefitClassInclusionJSON: 'SEB.FPE.Benefits.LibraryBenefitClassInclusionJSON',
        MemberClassDocument: 'SEB.FPE.Documents.MemberClassDocument',
        PlansponsorClassJson: 'SEB.FPE.Organizations.PlansponsorClassJson',
        PlansponsorClassEvent: 'SEB.FPE.EventProcessing.PlansponsorClassEvent',
        MemberStatusAutomationClass: 'SEB.FPE.Members.MemberStatusAutomationClass',
        User: 'SEB.FPE.Authorization.Users.User',
        ClassPensionAccountsEntity: 'SEB.FPE.PensionAccounts.ClassPensionAccount',
        ClassPensionAccountsTranslationEntity: 'SEB.FPE.PensionAccounts.ClassPensionAccountTranslation',
        RetirementSubscriptionsEntity: 'SEB.FPE.PensionAccounts.RetirementSubscription',
        tenantTranslation: 'SEB.FPE.TenantInfo.TenantTranslation',
        tenantAddress: 'SEB.FPE.TenantInfo.TenantAddress',
        tenantFinancial: 'SEB.FPE.TenantInfo.TenantFinancial',
        tenantFinancialTranslation: 'SEB.FPE.TenantInfo.TenantFinancialTranslation',
        personFinancialEntity: 'SEB.FPE.Persons.PersonFinancial',
        MemberEnrolmentWindow: 'SEB.FPE.Members.MemberEnrolmentWindow',
        Module: 'SEB.FPE.Modules.Module',
        ModuleTranslation: 'SEB.FPE.Modules.ModuleTranslation',
        ModuleDetail: 'SEB.FPE.Modules.ModuleDetail',
        ModuleBenefitMapping: 'SEB.FPE.Modules.ModuleBenefitMapping',
        ModuleCostShareDetails: 'SEB.FPE.Modules.ModuleCostShareDetails',
        tenantContactCentre: 'SEB.FPE.TenantInfo.ContactCentre',
        tenantContactCentreTranslation: 'SEB.FPE.TenantInfo.ContactCentreTranslation',
        PolicyDetail: 'SEB.FPE.Organizations.Policy.PolicyDetails',
        PlansponsorPolicyMapping: 'SEB.FPE.Organizations.Policy.PlansponsorPolicyMapping',
        CommunicationMessageTranslation: 'SEB.FPE.Communications.CommunicationMessageTranslation',
        BankFileMaster: 'SEB.FPE.TenantInfo.TenantBankFileMaster',
        BankFileDetail: 'SEB.FPE.TenantInfo.TenantBankFileDetail',
        PaymentMaster: 'SEB.FPE.Accounting.PaymentMaster',
        PaymentMasterCommissionSharing: 'SEB.FPE.Accounting.PaymentMasterCommissionSharing',
        PaymentMasterCarrier: 'SEB.FPE.Accounting.PaymentMasterCarrier',
        AdhocCredits: 'SEB.FPE.Exports.AdhocCredits',
        AdhocCreditTranslation: 'SEB.FPE.Exports.AdhocCreditsTranslation',
        CostCenter: 'SEB.FPE.CostCenter.OrganizationCostCenter',
        EnrollmentEventSetupMaster: 'SEB.FPE.AnnualEnrollment.EnrollmentEventSetupMaster',
        CommissionPaymentSetting: 'SEB.FPE.CommissionSetup.CommissionPaymentSetting',
        PlanponsorClassCalculatorProfileMapping: 'SEB.FPE.Organizations.PlanponsorClassCalculatorProfileMapping',
        CommunicationAttestation: 'SEB.FPE.Members.MemberAttestationSelection',
        libraryBenefitSubvendorAndErl: 'SEB.FPE.Benefits.LibraryBenefit'
    };

    static readonly MemberEntityType = {
        Class: 1,
        Division: 2,
        Status: 3
    };

    static readonly communicationTyps = {
        Email: 'Email',
        SMS: 'SMS',
        Notification: 'Notification',
        PcsNotification: 'PcsNotification',
        Mail: 'Mail',
    };
    static readonly LanguageSourceType = {
        Portal: 'Portal',
        Member: 'Member'
    }

    static readonly BoldBi = {
        filteredUrl: 'adminuserguid=@guid&ReportLanguage=@language@dateFilter',
        dateFilteredUrl: "&startdate=@startdate&enddate=@enddate",
        authorizationUrl: "/BoldBIEmbed/authorizationserver",
        getDashboardsUrl: "/BoldBIEmbed/getdashboards",
        getEmbedConfigUrl: "/BoldBIEmbed/getdata",
        languageEn: 'en-US',
        languageFr: 'fr-CA'
    };

    static readonly prorateFrequencySelectionType = {
        none: 'None',
        blank: '',
        DateJoinedInCalendarYear: 'DateJoinedInCalendarYear'
    };

    static readonly connectDashboard = {
        Allow: 'YES'
    };

    static readonly CountryCode = {
        Canada: 'CA',
    }

    static readonly NotificationStatus = {
        Queued: 'Queued',
        InProgress: 'InProgress',
        Failed: 'Failed',
        Successful: 'Successful',
        Mailed: 'Mailed',
        Hold: 'Hold',
        Discard: 'Discard'
    };

    static readonly sessionkey = {
        TPAAdminRetrodatelimitApplicable: 'TPAAdminRetrodatelimitApplicable',
        PSActiveDate: 'PSActiveDate'
    };

    static readonly uploadConfiguration = {
        DocFileSize: 10485760, // 10MB
        PDFFileSize: 10485760, // 10MB
        SmallPDFFileSize: 5024000, // 5MB
    }

    static readonly ClassCategory = {
        EmployeeOnly: 'EmployeeOnly'
    };
    static readonly SsoConfigLinkType = {
        ChangePassword: 'changepassword'
    };
}

export enum primaryFilter {
    memberData = 1,
    premiumData,
    groupData
}

export enum chartHeader {
    MemberStatus = 1,
    Plan,
    Carrier,
    Member,
    Renewals
}

export enum DropDownFilter {
    OfGroups = "groupData",
    OfMembers = "memberData",
    PremiumForGroups = "premiumData",
    PremiumForMembers = "premiumData2"
}

export enum PcsType {
    CoverageStatement = 1,
    PendingBeneficiary = 2,
    EOIApprovalForm = 3,
    DrugCard = 4,
    CostStatement = 5,
    StudentCertification = 6,
    MemberOverAge = 7,
    BeneficiaryStatement = 27
}

export const FilterTypeMapping: Record<DropDownFilter, string> = {
    [DropDownFilter.OfGroups]: "# of Plan Sponsors",
    [DropDownFilter.OfMembers]: "# of Members",
    [DropDownFilter.PremiumForGroups]: "Monthly Premium for Plan Sponsors",
    [DropDownFilter.PremiumForMembers]: "Monthly Premium for Members",
}

export const FilterTypeMappingFR: Record<DropDownFilter, string> = {
    [DropDownFilter.OfGroups]: "# de Promoteur de régime",
    [DropDownFilter.OfMembers]: "# de participants",
    [DropDownFilter.PremiumForGroups]: "Prime mensuelle pour les promoteurs de régime",
    [DropDownFilter.PremiumForMembers]: "Prime mensuelle pour les participants",
}

export const GraphType: Record<chartHeader, string> = {
    [chartHeader.MemberStatus]: "memberData|line:groupData|NA:premiumData|line:premiumData2|NA",
    [chartHeader.Plan]: "memberData|line:groupData|line:premiumData|pie:premiumData2|NA",
    [chartHeader.Carrier]: "memberData|pie:groupData|pie:premiumData|pie:premiumData2|NA",
    [chartHeader.Member]: "memberData|line:groupData|bar:premiumData|bar:premiumData2|Line",
    [chartHeader.Renewals]: "memberData|pie:groupData|pie:premiumData|pie:premiumData2|NA"
}
