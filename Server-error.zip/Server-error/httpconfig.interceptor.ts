import { Injectable } from '@angular/core';
import {
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpErrorResponse
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { AppConsts } from '@shared/AppConsts';
@Injectable()
export class HttpConfigInterceptor implements HttpInterceptor {
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        //const token: string = localStorage.getItem('token');
        const token = abp.auth.getToken();

        if (token) {
            let JSONEmpObject = JSON.parse(sessionStorage.getItem('MemberDetails'));
            if (JSONEmpObject != null) {
                //console.log('JSONEmpObject',JSONEmpObject,"MemberId", JSONEmpObject.MemberId);

                request = request.clone({
                    headers: request.headers
                        .set('memberid', JSONEmpObject.MemberId)
                        .set('organizationid', JSONEmpObject.OrgId)
                        .set('plansponserid', JSONEmpObject.PsId)
                        .set('personid', JSONEmpObject.personId)
                });
                // console.log("request.headers",request.headers);
            }
            //request = request.clone({ headers: request.headers.set('AuthorizationZZ', 'BearerKK ' + token) });
        }

        if ((request.method === 'POST' || request.method === 'PUT' || request.method === 'DELETE') && !request.headers.has(abp.security.antiForgery.tokenHeaderName)) {
            // if (abp.security.antiForgery.getToken()) {
            //     request = request.clone({ headers: request.headers.set(abp.security.antiForgery.tokenHeaderName, abp.security.antiForgery.getToken()) });
            // }
            const antiForgeryToken = sessionStorage.getItem(abp.security.antiForgery.tokenCookieName);
            if (antiForgeryToken) {
                request = request.clone({ headers: request.headers.set(abp.security.antiForgery.tokenHeaderName, antiForgeryToken) });
            }
        }


        // if (!request.headers.has('Content-Type')) {
        //     request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
        // }

        // request = request.clone({ headers: request.headers.set('Accept', 'application/json') });

        return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                    //console.log('event--->>>', event);
                }
                return event;
            }),
            catchError((error: HttpErrorResponse) => {
                this.handleInternalServerError(error);
                return throwError(error);
            }));
    }

    private handleInternalServerError(error: HttpErrorResponse): void {
        if (!error || error.status !== 500) {
            return;
        }

        const configuredAction = (AppConsts.loginInternalServerErrorAction || AppConsts.loginErrorActions.none).toLowerCase();

        if (configuredAction === AppConsts.loginErrorActions.refresh) {
            window.location.reload();
            return;
        }

        if (configuredAction === AppConsts.loginErrorActions.logout) {
            abp.auth.clearToken();
            abp.auth.clearRefreshToken();
            localStorage.removeItem(AppConsts.authorization.encrptedAuthTokenName);
            abp.utils.deleteCookie(abp.security.antiForgery.tokenCookieName);
            sessionStorage.removeItem("MemberDetails");
            sessionStorage.removeItem("DashboardDetails");
            sessionStorage.removeItem("IsNewMemPortal");
            sessionStorage.removeItem("AdminOktaSSO");
            location.href = '/account/login';
        }
    }
}
